<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * SCRIPT DE INSTALACIÓN - IMPORT PROJECTS (Versión Compatible)
 * ----------------------------------------------------------
 * @version 1.1.1
 * @author Miguel Angel Sánchez
 */

$CI = &get_instance();

// ==========================================
// 1. REGISTRO MANUAL DEL MÓDULO
// ==========================================
$module_data = [
    'module_name' => 'import_projects',
    'installed_version' => '1.1.1',
    'active' => 1
];

// Verificar si el módulo ya está registrado
$existing_module = $CI->db->where('module_name', 'import_projects')
                         ->get(db_prefix().'modules')
                         ->row();

if (!$existing_module) {
    $CI->db->insert(db_prefix().'modules', $module_data);
}

// ==========================================
// 2. CREACIÓN DE TABLAS
// ==========================================
$tables_created = false;

// Tabla de historial (versión optimizada)
if (!$CI->db->table_exists(db_prefix() . 'import_projects_history')) {
    $CI->db->query("
        CREATE TABLE IF NOT EXISTS `".db_prefix()."import_projects_history` (
            `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `staff_id` INT(11) NOT NULL,
            `file_name` VARCHAR(255) NOT NULL,
            `file_path` VARCHAR(512) DEFAULT NULL,
            `total_rows` MEDIUMINT(8) NOT NULL DEFAULT 0,
            `imported_rows` MEDIUMINT(8) NOT NULL DEFAULT 0,
            `failed_rows` MEDIUMINT(8) NOT NULL DEFAULT 0,
            `ip_address` VARCHAR(45) DEFAULT NULL,
            `status` ENUM('pending','completed','partial','failed') DEFAULT 'pending',
            `notes` TEXT DEFAULT NULL,
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `staff_id_index` (`staff_id`),
            KEY `status_index` (`status`),
            KEY `date_index` (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    $tables_created = true;
}

// Tabla de filas importadas (versión optimizada)
if (!$CI->db->table_exists(db_prefix() . 'import_projects_rows')) {
    $CI->db->query("
        CREATE TABLE IF NOT EXISTS `".db_prefix()."import_projects_rows` (
            `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `history_id` INT(11) NOT NULL,
            `project_id` INT(11) DEFAULT NULL,
            `row_number` MEDIUMINT(8) NOT NULL,
            `project_name` VARCHAR(255) NOT NULL,
            `client_id` INT(11) DEFAULT NULL,
            `client_raw` VARCHAR(255) DEFAULT NULL,
            `start_date` DATE DEFAULT NULL,
            `end_date` DATE DEFAULT NULL,
            `status` ENUM('pending','success','failed') DEFAULT 'pending',
            `error_message` TEXT DEFAULT NULL,
            `metadata` JSON DEFAULT NULL,
            `processed_at` DATETIME DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `history_id_index` (`history_id`),
            KEY `project_id_index` (`project_id`),
            KEY `status_index` (`status`),
            CONSTRAINT `fk_history` FOREIGN KEY (`history_id`) 
            REFERENCES `".db_prefix()."import_projects_history` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    $tables_created = true;
}

// ==========================================
// 3. CONFIGURACIÓN INICIAL (Método Compatible)
// ==========================================
$default_settings = [
    'csv_delimiter' => ',',
    'enclosure' => '"',
    'escape' => '\\',
    'max_file_size' => 5,
    'keep_history_days' => 90,
    'default_date_format' => 'Y-m-d',
    'notify_on_failure' => 1
];

if (!$CI->db->where('name', 'import_projects_settings')->get(db_prefix().'options')->row()) {
    $CI->db->insert(db_prefix().'options', [
        'name' => 'import_projects_settings',
        'value' => json_encode($default_settings),
        'autoload' => 1
    ]);
}

// ==========================================
// 4. REGISTRO DE HOOKS (Método Compatible)
// ==========================================
// Verificar si el hook ya existe antes de insertar
$existing_hook = $CI->db->where('hook', 'admin_init')
                       ->where('function', 'import_projects_init_menu_items')
                       ->get(db_prefix().'hooks')
                       ->row();

if (!$existing_hook) {
    $CI->db->insert(db_prefix().'hooks', [
        'hook' => 'admin_init',
        'function' => 'import_projects_init_menu_items',
        'priority' => 10
    ]);
}

// ==========================================
// 5. FINALIZACIÓN DE INSTALACIÓN
// ==========================================
if ($tables_created) {
    log_activity('Import Projects Module Installed (v1.1.1)');
    
    // Método compatible para guardar versión
    $CI->db->where('name', 'import_projects_installed_version');
    if (!$CI->db->get(db_prefix().'options')->row()) {
        $CI->db->insert(db_prefix().'options', [
            'name' => 'import_projects_installed_version',
            'value' => '1.1.1',
            'autoload' => 0
        ]);
    }
}