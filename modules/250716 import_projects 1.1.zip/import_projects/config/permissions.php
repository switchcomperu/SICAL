<?php

defined('BASEPATH') or exit('No direct script access allowed');

$capabilities = [];

$capabilities['capabilities'] = [
    'view'   => _l('permission_view'),
    'create' => _l('permission_create'),
    'edit'   => _l('permission_edit'),
    'delete' => _l('permission_delete'),
];

hooks()->add_filter('staff_permissions', function ($permissions) use ($capabilities) {
    $permissions['import_projects'] = $capabilities;
    return $permissions;
});
