<?php

defined('BASEPATH') or exit('No direct script access allowed');

$CI =& get_instance();

register_language_files('import_projects', ['import_projects']);

$config['name']        = 'import_projects';
$config['version']     = '1.0.0';
$config['author']      = 'ChatGPT Mejorado';
$config['author_uri']  = 'https://openai.com';
$config['description'] = 'Módulo para importar proyectos desde archivo CSV';
