<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Csvimport
{
    private $delimiter = ',';
    private $enclosure = '"';
    private $escape = '\\';

    /**
     * Lee un archivo CSV y lo convierte en un array asociativo
     *
     * @param string $filepath Ruta del archivo CSV
     * @return array|bool Datos en forma de array o false si ocurre un error
     */
    public function get_array($filepath)
    {
        if (!file_exists($filepath) || !is_readable($filepath)) {
            return false;
        }

        $header = null;
        $data = [];

        if (($handle = fopen($filepath, 'r')) !== false) {
            while (($row = fgetcsv($handle, 1000, $this->delimiter, $this->enclosure, $this->escape)) !== false) {
                if (!$header) {
                    $header = $row;
                } else {
                    $data[] = array_combine($header, $row);
                }
            }
            fclose($handle);
        }

        return $data;
    }

    /**
     * Permite establecer un delimitador personalizado
     */
    public function set_delimiter($delimiter)
    {
        $this->delimiter = $delimiter;
    }

    /**
     * Permite establecer un carácter de comillas personalizado
     */
    public function set_enclosure($enclosure)
    {
        $this->enclosure = $enclosure;
    }

    /**
     * Permite establecer un carácter de escape personalizado
     */
    public function set_escape($escape)
    {
        $this->escape = $escape;
    }
}
