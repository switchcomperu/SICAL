<?php

defined('BASEPATH') or exit('No direct script access allowed');

/*
Module Name: Import Projects
Description: Importación de proyectos desde archivo CSV con historial.
Version: 1.0.0
Requires at least: 2.3.*
Author: ChatGPT Mejorado
*/

register_activation_hook('import_projects', 'import_projects_module_activate');
register_uninstall_hook('import_projects', 'import_projects_module_uninstall');
register_language_files('import_projects', ['import_projects']);
require_once(__DIR__ . '/helpers/import_projects_helper.php');

// Agregar ítem de menú en admin
hooks()->add_action('admin_init', 'import_projects_module_init_menu');

// Activación del módulo (creación de tablas)
function import_projects_module_activate()
{
    $CI = &get_instance();
    require_once(__DIR__ . '/install.php');
}

// Desinstalación del módulo (eliminación de tablas)
function import_projects_module_uninstall()
{
    require_once(__DIR__ . '/uninstall.php');
}

// Menú del módulo
function import_projects_module_init_menu()
{
    import_projects_module_init_menu_items();
}
