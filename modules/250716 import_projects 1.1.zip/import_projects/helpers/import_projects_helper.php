<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Inicializa y agrega elementos del menú del módulo "Import Projects"
 */
function import_projects_module_init_menu_items()
{
    $CI = &get_instance();

    if (has_permission('import_projects', '', 'view')) {
        // Menú principal
        $CI->app_menu->add_sidebar_menu_item('import_projects', [
            'slug'     => 'import_projects',
            'name'     => _l('import_projects'), // traducido
            'icon'     => 'fa fa-upload',
            'href'     => admin_url('import_projects'),
            'position' => 30,
            'collapse' => true,
        ]);

        // Submenú: Importar
        if (has_permission('import_projects', '', 'create')) {
            $CI->app_menu->add_sidebar_children_item('import_projects', [
                'slug'     => 'import_projects-importar',
                'name'     => _l('import_projects_importar'),
                'href'     => admin_url('import_projects'),
                'position' => 1,
            ]);
        }

        // Submenú: Historial
        if (has_permission('import_projects', '', 'view')) {
            $CI->app_menu->add_sidebar_children_item('import_projects', [
                'slug'     => 'import_projects-historial',
                'name'     => _l('import_projects_historial'),
                'href'     => admin_url('import_projects/history'),
                'position' => 2,
            ]);
        }

        // Submenú: Configuración (ejemplo)
        if (has_permission('import_projects', '', 'edit')) {
            $CI->app_menu->add_sidebar_children_item('import_projects', [
                'slug'     => 'import_projects-config',
                'name'     => _l('import_projects_config'),
                'href'     => admin_url('import_projects/settings'),
                'position' => 3,
            ]);
        }

        // Si quieres permitir eliminar registros desde menú (poco común)
        if (has_permission('import_projects', '', 'delete')) {
            $CI->app_menu->add_sidebar_children_item('import_projects', [
                'slug'     => 'import_projects-delete',
                'name'     => _l('import_projects_eliminar'),
                'href'     => admin_url('import_projects/delete'),
                'position' => 4,
            ]);
        }
    }
}
