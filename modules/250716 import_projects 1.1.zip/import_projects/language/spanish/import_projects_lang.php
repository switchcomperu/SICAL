<?php

$lang['import_projects']                = 'Importar Proyectos';
$lang['import_projects_menu']           = 'Importar Proyectos';
$lang['import_projects_heading']        = 'Importar desde archivo CSV';
$lang['import_projects_subheading']     = 'Sube un archivo con proyectos para importar';

$lang['import_projects_file']           = 'Seleccionar archivo CSV';
$lang['import_projects_upload']         = 'Cargar y previsualizar';
$lang['import_projects_confirm']        = 'Confirmar Importación';
$lang['import_projects_success']        = 'Importación completada correctamente.';
$lang['import_projects_errors']         = 'Errores encontrados';
$lang['import_projects_preview']        = 'Vista previa de importación';
$lang['import_projects_history']        = 'Historial de Importaciones';
$lang['import_projects_download_template'] = 'Descargar Plantilla CSV';

$lang['import_projects_column_project'] = 'Proyecto';
$lang['import_projects_column_client']  = 'Cliente';
$lang['import_projects_column_start']   = 'Inicio';
$lang['import_projects_column_end']     = 'Fin';

// Permisos
$lang['permission_view']   = 'Ver';
$lang['permission_create'] = 'Crear';
$lang['permission_edit']   = 'Editar';
$lang['permission_delete'] = 'Eliminar';
