<?php

$lang['import_projects']                = 'Import Projects';
$lang['import_projects_menu']           = 'Import Projects';
$lang['import_projects_heading']        = 'Import from CSV file';
$lang['import_projects_subheading']     = 'Upload a file with projects to import';

$lang['import_projects_file']           = 'Select CSV file';
$lang['import_projects_upload']         = 'Upload and Preview';
$lang['import_projects_confirm']        = 'Confirm Import';
$lang['import_projects_success']        = 'Import completed successfully.';
$lang['import_projects_errors']         = 'Errors Found';
$lang['import_projects_preview']        = 'Import Preview';
$lang['import_projects_history']        = 'Import History';
$lang['import_projects_download_template'] = 'Download CSV Template';

$lang['import_projects_column_project'] = 'Project';
$lang['import_projects_column_client']  = 'Client';
$lang['import_projects_column_start']   = 'Start Date';
$lang['import_projects_column_end']     = 'End Date';

// Permissions
$lang['permission_view']   = 'View';
$lang['permission_create'] = 'Create';
$lang['permission_edit']   = 'Edit';
$lang['permission_delete'] = 'Delete';
