<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="no-margin">Historial de Importaciones</h4>
            <hr />
            <?php if (!empty($history)): ?>
              <div class="table-responsive">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Archivo</th>
                      <th>Total Importados</th>
                      <th>Usuario</th>
                      <th>Fecha</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($history as $index => $h): ?>
                      <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td><?php echo html_escape($h['file_name']); ?></td>
                        <td><?php echo $h['total_imported']; ?></td>
                        <td><?php echo get_staff_full_name($h['staff_id']); ?></td>
                        <td><?php echo _dt($h['date']); ?></td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php else: ?>
              <p class="text-muted">Aún no hay historial de importaciones.</p>
            <?php endif; ?>
            <a href="<?php echo admin_url('import_projects'); ?>" class="btn btn-secondary mt-3">
              <i class="fa fa-arrow-left"></i> Regresar
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
</body>
</html>
