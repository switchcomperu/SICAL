<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="no-margin mb-4">Vista Previa de la Importación</h4>

            <?php if (isset($rows) && count($rows) > 0): ?>
              <div class="table-responsive">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th>Proyecto</th>
                      <th>Cliente</th>
                      <th>Inicio</th>
                      <th>Fin</th>
                      <th>Errores</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($rows as $row): ?>
                      <tr>
                        <td><?php echo html_escape($row['project']); ?></td>
                        <td><?php echo html_escape($row['client']); ?></td>
                        <td><?php echo html_escape($row['start']); ?></td>
                        <td><?php echo html_escape($row['end']); ?></td>
                        <td>
                          <?php
                            if (!empty($row['errors'])) {
                              echo '<span class="text-danger"><ul>';
                              foreach ($row['errors'] as $error) {
                                echo '<li>' . html_escape($error) . '</li>';
                              }
                              echo '</ul></span>';
                            } else {
                              echo '<span class="text-success">Sin errores</span>';
                            }
                          ?>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>

              <hr>
              <?php echo form_open(admin_url('import_projects/confirm_upload')); ?>
                <button type="submit" class="btn btn-success">
                  <i class="fa fa-check"></i> Confirmar e Importar
                </button>
                <a href="<?php echo admin_url('import_projects'); ?>" class="btn btn-secondary ml-2">Cancelar</a>
              <?php echo form_close(); ?>

            <?php else: ?>
              <p class="text-warning">No hay datos para mostrar.</p>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
</body>
</html>
