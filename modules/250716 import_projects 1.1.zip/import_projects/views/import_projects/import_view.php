<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="no-margin">Importar Proyectos desde CSV</h4>
            <hr />
            <?php echo form_open_multipart(admin_url('import_projects/preview_upload')); ?>
              <div class="form-group">
                <label for="file_csv">Seleccionar archivo CSV</label>
                <input type="file" name="file_csv" id="file_csv" class="form-control" accept=".csv" required />
                <small class="text-muted">Formato esperado: Proyecto, Cliente, Fecha Inicio (Y-m-d), Fecha Fin (Y-m-d)</small>
              </div>
              <button type="submit" class="btn btn-primary">Vista Previa</button>
              <a href="<?php echo module_dir_url('import_projects', 'sample.csv'); ?>" class="btn btn-default">Descargar Plantilla</a>
            <?php echo form_close(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
</body>
</html>
