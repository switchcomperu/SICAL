<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="no-margin">Configuración del módulo Import Projects</h4>
            <hr />
            <?php echo form_open(admin_url('import_projects/save_settings')); ?>

            <div class="form-group">
              <label for="csv_delimiter">Delimitador CSV</label>
              <input type="text" class="form-control" name="csv_delimiter" value="<?php echo get_option('import_projects_csv_delimiter', ','); ?>" />
            </div>

            <div class="form-group">
              <label for="date_format">Formato de fecha (Ej: Y-m-d)</label>
              <input type="text" class="form-control" name="date_format" value="<?php echo get_option('import_projects_date_format', 'Y-m-d'); ?>" />
            </div>

            <button type="submit" class="btn btn-primary">Guardar Configuración</button>
            <?php echo form_close(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
</body>
</html>
