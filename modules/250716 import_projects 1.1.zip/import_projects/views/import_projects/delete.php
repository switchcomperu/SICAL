<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-6">
        <div class="panel_s">
          <div class="panel-body">
            <h4>Eliminar Registros de Importaciones</h4>
            <hr />
            <?php echo form_open(admin_url('import_projects/delete_history')); ?>
              <div class="form-group">
                <label for="days">Eliminar registros con más de (días):</label>
                <input type="number" name="days" class="form-control" min="1" required />
              </div>
              <button type="submit" class="btn btn-danger">Eliminar</button>
            <?php echo form_close(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
</body>
</html>
