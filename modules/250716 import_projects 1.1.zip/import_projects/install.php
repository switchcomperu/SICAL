<?php

defined('BASEPATH') or exit('No direct script access allowed');

$CI =& get_instance();

// Tabla para historial de importaciones
if (!$CI->db->table_exists(db_prefix() . 'import_projects_history')) {
    $CI->db->query('
        CREATE TABLE `' . db_prefix() . 'import_projects_history` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `staff_id` INT UNSIGNED NOT NULL,
            `file_name` VARCHAR(255) NOT NULL,
            `total_imported` INT UNSIGNED NOT NULL DEFAULT 0,
            `date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ');
}

// Tabla para filas importadas
if (!$CI->db->table_exists(db_prefix() . 'import_projects_rows')) {
    $CI->db->query('
        CREATE TABLE `' . db_prefix() . 'import_projects_rows` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `history_id` INT UNSIGNED NOT NULL DEFAULT 0,
            `project_name` VARCHAR(255) NOT NULL,
            `client` VARCHAR(255) NOT NULL,
            `start_date` DATE NOT NULL,
            `end_date` DATE NOT NULL,
            PRIMARY KEY (`id`),
            KEY `history_id` (`history_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ');
}
