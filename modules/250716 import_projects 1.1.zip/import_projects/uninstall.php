<?php

defined('BASEPATH') or exit('No direct script access allowed');

$CI =& get_instance();

// Eliminar tabla de filas importadas
$CI->db->query('DROP TABLE IF EXISTS `' . db_prefix() . 'import_projects_rows`');

// Eliminar tabla de historial de importaciones
$CI->db->query('DROP TABLE IF EXISTS `' . db_prefix() . 'import_projects_history`');
