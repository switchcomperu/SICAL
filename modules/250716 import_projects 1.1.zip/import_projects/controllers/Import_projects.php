<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Import_projects extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('import_projects_model');

        // Solo cargar si vas a usarla, puedes eliminarla si no
        // $this->load->library('csvimport');
    }

    /**
     * Página principal del módulo
     */
    public function index()
    {
        $this->load->view('import_projects/import_view');
    }

    /**
     * Procesar archivo CSV para previsualización
     */
    public function preview_upload()
    {
        if (!isset($_FILES['file_csv']) || $_FILES['file_csv']['error'] !== UPLOAD_ERR_OK) {
            set_alert('danger', 'Archivo no válido.');
            redirect(admin_url('import_projects'));
        }

        $file = $_FILES['file_csv']['tmp_name'];
        $handle = fopen($file, 'r');

        if (!$handle) {
            set_alert('danger', 'No se pudo abrir el archivo.');
            redirect(admin_url('import_projects'));
        }

        $preview_data = [];
        $row_index = 0;

        while (($data = fgetcsv($handle, 1000, ',')) !== false) {
            $row_index++;
            if ($row_index == 1) continue; // Saltar encabezado

            // Soporte UTF-8 para evitar problemas con tildes
            $data = array_map(function ($field) {
                return trim(mb_convert_encoding($field, 'UTF-8', 'auto'));
            }, $data);

            $project = $data[0] ?? '';
            $client  = $data[1] ?? '';
            $start   = $data[2] ?? '';
            $end     = $data[3] ?? '';

            $errors = [];
            if (!$project) $errors[] = 'Falta nombre del proyecto';
            if (!$client)  $errors[] = 'Falta nombre del cliente';
            if (!$this->validate_date($start)) $errors[] = 'Fecha de inicio inválida';
            if (!$this->validate_date($end))   $errors[] = 'Fecha de fin inválida';

            $preview_data[] = [
                'project' => $project,
                'client'  => $client,
                'start'   => $start,
                'end'     => $end,
                'errors'  => $errors,
            ];
        }

        fclose($handle);

        $this->session->set_userdata('import_preview_data', $preview_data);
        $this->session->set_userdata('import_filename', $_FILES['file_csv']['name']);

        $data['rows'] = $preview_data;
        $data['title'] = 'Vista previa de importación';
        $this->load->view('import_projects/preview', $data);
    }

    /**
     * Confirmar e insertar los datos válidos
     */
    public function confirm_upload()
    {
        $rows = $this->session->userdata('import_preview_data');
        $file_name = $this->session->userdata('import_filename');
        $total_imported = 0;

        if (!is_array($rows)) {
            set_alert('danger', 'No hay datos para importar.');
            redirect(admin_url('import_projects'));
        }

        foreach ($rows as $r) {
            if (!empty($r['errors'])) continue;

            $this->db->insert(db_prefix() . 'import_projects_rows', [
                'project_name' => $r['project'],
                'client'       => $r['client'],
                'start_date'   => $r['start'],
                'end_date'     => $r['end'],
                'history_id'   => 0, // Se actualiza después
            ]);
            $total_imported++;
        }

        $history_id = $this->import_projects_model->log_import(get_staff_user_id(), $file_name, $total_imported);
        $this->db->where('history_id', 0)->update(db_prefix() . 'import_projects_rows', ['history_id' => $history_id]);

        $this->session->unset_userdata('import_preview_data');
        $this->session->unset_userdata('import_filename');

        set_alert('success', 'Importación completada correctamente.');
        redirect(admin_url('import_projects/history'));
    }

    /**
     * Historial de importaciones
     */
    public function history()
    {
        $data['history'] = $this->import_projects_model->get_import_history();
        $this->load->view('import_projects/history', $data);
    }

    /**
     * Validar formato de fecha (Y-m-d)
     */
    private function validate_date($date, $format = 'Y-m-d')
    {
        $d = DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) === $date;
    }

    /**
     * Descargar plantilla CSV
     */
    public function download_template()
    {
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="plantilla_proyectos.csv"');
        echo "Proyecto,Cliente,Inicio,Fin\n";
        echo "Proyecto A,Cliente 1,2025-01-01,2025-01-31\n";
        echo "Proyecto B,Cliente 2,2025-02-01,2025-03-01\n";
        exit;
    }
}
