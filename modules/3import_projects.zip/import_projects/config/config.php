<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Configuración del módulo Import Projects
 */

// Registrar archivos de idioma
$CI =& get_instance();
register_language_files('import_projects', ['import_projects']);

// Metadatos del módulo
$config['name']        = 'import_projects';
$config['version']     = '1.0.0';
$config['author']      = 'Miguel Angel Sánchez';
$config['author_uri']  = 'https://github.com/miguelangel-sanchez';
$config['description'] = 'Módulo para importar proyectos desde archivos CSV.';

// Configuración del importador CSV (si se usa librería)
$config['csv_import'] = [
    'delimiter'         => ',',
    'skip_empty_lines'  => true,
    'trim_fields'       => true,
];

// Permisos personalizados para el módulo
$config['permissions'] = [
    'import_projects' => [
        'name'        => 'import_projects',
        'label'       => _l('Import Projects'),
        'description' => 'Permitir acceso al módulo de importación de proyectos',
        'default_staff_permissions' => ['view', 'create'],
    ],
];
// Configuración de la tabla de historial de importaciones
