<?php

defined('BASEPATH') or exit('No direct script access allowed');

/*
Module Name: Import Projects
Description: Importación de proyectos desde archivo CSV con historial.
Version: 1.0.0
Requires at least: 2.3.*
Author: ChatGPT
*/

// Hooks de activación/desinstalación
register_activation_hook('import_projects', 'import_projects_module_activate');
register_uninstall_hook('import_projects', 'import_projects_module_uninstall');

// Archivos de idioma
register_language_files('import_projects', ['import_projects']);

// Cargar helper del módulo
require_once __DIR__ . '/helpers/import_projects_helper.php';

// Registrar menú en el panel de administración
hooks()->add_action('admin_init', 'import_projects_module_init_menu_items');

/**
 * Activación del módulo: crea tablas necesarias
 */
function import_projects_module_activate()
{
    require_once __DIR__ . '/install.php';
}

/**
 * Desinstalación del módulo: elimina tablas y datos
 */
function import_projects_module_uninstall()
{
    require_once __DIR__ . '/uninstall.php';
}
