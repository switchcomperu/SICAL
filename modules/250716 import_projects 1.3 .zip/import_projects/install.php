<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * SCRIPT DE INSTALACIÓN - IMPORT PROJECTS
 * ---------------------------------------
 * @version 1.1.0
 * @author Miguel Angel Sánchez
 */

$CI = &get_instance();

// ==========================================
// 1. REGISTRO DEL MÓDULO EN EL SISTEMA
// ==========================================
register_module([
    'name' => 'Import Projects',
    'version' => '1.1.0',
    'author' => 'Miguel Angel Sánchez',
    'description' => 'Módulo para importar proyectos desde archivos CSV',
    'database_tables' => [
        db_prefix() . 'import_projects_history',
        db_prefix() . 'import_projects_rows'
    ]
]);

// ==========================================
// 2. CREACIÓN DE TABLAS EN LA BASE DE DATOS
// ==========================================
$tables_created = false;

// Tabla de historial
if (!$CI->db->table_exists(db_prefix() . 'import_projects_history')) {
    $CI->db->query("
        CREATE TABLE `" . db_prefix() . "import_projects_history` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `staff_id` INT NOT NULL,
            `file_name` VARCHAR(255) NOT NULL,
            `file_path` VARCHAR(512) NULL,
            `total_rows` INT NOT NULL DEFAULT 0,
            `imported_rows` INT NOT NULL DEFAULT 0,
            `failed_rows` INT NOT NULL DEFAULT 0,
            `ip_address` VARCHAR(45) NULL,
            `status` ENUM('pending', 'completed', 'partial', 'failed') DEFAULT 'pending',
            `notes` TEXT NULL,
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            INDEX `staff_id_index` (`staff_id`),
            INDEX `status_index` (`status`),
            INDEX `date_index` (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    $tables_created = true;
}

// Tabla de filas importadas
if (!$CI->db->table_exists(db_prefix() . 'import_projects_rows')) {
    $CI->db->query("
        CREATE TABLE `" . db_prefix() . "import_projects_rows` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `history_id` INT NOT NULL,
            `project_id` INT NULL,
            `row_number` INT NOT NULL,
            `project_name` VARCHAR(255) NOT NULL,
            `client_id` INT NULL,
            `client_raw` VARCHAR(255) NULL,
            `start_date` DATE NULL,
            `end_date` DATE NULL,
            `status` ENUM('pending', 'success', 'failed') DEFAULT 'pending',
            `error_message` TEXT NULL,
            `metadata` JSON NULL,
            `processed_at` DATETIME NULL,
            PRIMARY KEY (`id`),
            FOREIGN KEY (`history_id`) 
                REFERENCES `" . db_prefix() . "import_projects_history`(`id`)
                ON DELETE CASCADE,
            INDEX `history_id_index` (`history_id`),
            INDEX `project_id_index` (`project_id`),
            INDEX `status_index` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    $tables_created = true;
}

// ==========================================
// 3. CONFIGURACIÓN INICIAL
// ==========================================
$default_settings = [
    'csv_delimiter' => ',',
    'enclosure' => '"',
    'escape' => '\\',
    'max_file_size' => 5, // MB
    'keep_history_days' => 90,
    'default_date_format' => 'Y-m-d',
    'notify_on_failure' => 1
];

if (!$CI->db->where('name', 'import_projects_settings')->get(db_prefix() . 'options')->row()) {
    $CI->db->insert(db_prefix() . 'options', [
        'name' => 'import_projects_settings',
        'value' => json_encode($default_settings),
        'autoload' => 1
    ]);
}

// ==========================================
// 4. REGISTRO DE HOOKS Y EVENTOS
// ==========================================
register_hook('admin_init', 'import_projects_init_menu_items');
register_hook('after_cron_run', 'import_projects_purge_old_imports');

// ==========================================
// 5. INSTALACIÓN COMPLETADA
// ==========================================
if ($tables_created) {
    log_activity('Import Projects Module Installed (v1.1.0)');
    update_option('import_projects_installed_version', '1.1.0');
}