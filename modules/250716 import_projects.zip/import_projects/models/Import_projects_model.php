<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Import_projects_model extends App_Model
{
    protected $table;

    public function __construct()
    {
        parent::__construct();
        $this->table = db_prefix() . 'import_projects_history';
    }

    /**
     * Obtiene el historial completo de importaciones.
     *
     * @return array
     */
    public function get_import_history()
    {
        return $this->db->order_by('date', 'DESC')->get($this->table)->result_array();
    }

    /**
     * Filtra el historial por rango de fechas y usuario.
     *
     * @param string|null $from
     * @param string|null $to
     * @param int|null $staff_id
     * @return array
     */
    public function filter_history($from = null, $to = null, $staff_id = null)
    {
        if ($from) {
            $this->db->where('date >=', $from . ' 00:00:00');
        }

        if ($to) {
            $this->db->where('date <=', $to . ' 23:59:59');
        }

        if ($staff_id) {
            $this->db->where('staff_id', $staff_id);
        }

        return $this->db->order_by('date', 'DESC')->get($this->table)->result_array();
    }

    /**
     * Registra una nueva importación en la base de datos.
     *
     * @param int $staff_id
     * @param string $file_name
     * @param int $total_imported
     * @return int
     */
    public function log_import($staff_id, $file_name, $total_imported)
    {
        $data = [
            'staff_id'       => $staff_id,
            'file_name'      => $file_name,
            'total_imported' => $total_imported,
            'date'           => date('Y-m-d H:i:s'),
        ];

        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    /**
     * Obtiene todas las filas importadas por ID de historial.
     *
     * @param int $history_id
     * @return array
     */
    public function get_rows_by_history($history_id)
    {
        return $this->db->where('history_id', $history_id)
                        ->get(db_prefix() . 'import_projects_rows')
                        ->result_array();
    }
}
