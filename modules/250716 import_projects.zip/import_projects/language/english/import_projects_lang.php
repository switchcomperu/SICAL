<?php

$lang['import_projects'] = 'Import Projects';
$lang['import_projects_desc'] = 'Import projects from a CSV file. The file should contain the project name, description, and other relevant details.';
$lang['import_projects_file'] = 'Select CSV file';
$lang['import_projects_file_desc'] = 'Choose a CSV file to import projects from.';
$lang['import_projects_success'] = 'Projects imported successfully.';
$lang['import_projects_error'] = 'An error occurred while importing projects. Please check the file format and try again.';
$lang['import_projects_invalid_file'] = 'The selected file is not a valid CSV file. Please upload a valid CSV file.';
$lang['Importar Proyectos'] = 'Importar Proyectos';
$lang['Importar'] = 'Importar';
$lang['Historial'] = 'Historial';

?>
