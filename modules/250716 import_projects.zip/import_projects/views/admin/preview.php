<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="no-margin">Vista Previa de Importación</h4>
            <hr>

            <div class="alert alert-info">
              Revisa los datos antes de confirmar. Las filas con errores están resaltadas en rojo.
            </div>

            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>Proyecto</th>
                  <th>Cliente</th>
                  <th>Inicio</th>
                  <th>Fin</th>
                  <th>Errores</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($rows as $r): ?>
                  <tr class="<?= count($r['errors']) ? 'bg-danger text-white' : ''; ?>">
                    <td><?= htmlspecialchars($r['project']); ?></td>
                    <td><?= htmlspecialchars($r['client']); ?></td>
                    <td><?= htmlspecialchars($r['start']); ?></td>
                    <td><?= htmlspecialchars($r['end']); ?></td>
                    <td>
                      <?php if (!empty($r['errors'])): ?>
                        <ul>
                          <?php foreach ($r['errors'] as $error): ?>
                            <li><?= htmlspecialchars($error); ?></li>
                          <?php endforeach; ?>
                        </ul>
                      <?php else: ?>
                        <span class="text-success">Sin errores</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>

            <hr>
            <a href="<?= admin_url('import_projects/confirm_upload') ?>" class="btn btn-success">Confirmar Importación</a>
            <a href="<?= admin_url('import_projects') ?>" class="btn btn-secondary">Cancelar</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
</body>
</html>
