<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="no-margin">Historial de Importaciones</h4>
            <hr>

            <?php if (!empty($history)) : ?>
              <div class="table-responsive">
                <table class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Archivo</th>
                      <th>Importados</th>
                      <th>Usuario</th>
                      <th>Fecha</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($history as $index => $row): ?>
                      <tr>
                        <td><?= $index + 1; ?></td>
                        <td><?= htmlspecialchars($row['file_name']); ?></td>
                        <td><?= (int) $row['total_imported']; ?></td>
                        <td><?= get_staff_full_name($row['staff_id']); ?></td>
                        <td><?= _dt($row['date']); ?></td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php else: ?>
              <p class="text-muted">No se ha registrado ninguna importación aún.</p>
            <?php endif; ?>

            <hr>
            <a href="<?= admin_url('import_projects'); ?>" class="btn btn-default">Volver a Importar</a>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
</body>
</html>
