<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="mbot20"><?php echo _l('Importar Proyectos desde CSV'); ?></h4>
            <hr />

            <?php echo form_open_multipart(admin_url('import_projects/preview_upload'), ['id' => 'import_form']); ?>
              <div class="form-group">
                <label for="file_csv" class="control-label">
                  <?php echo _l('Seleccionar archivo CSV'); ?>
                  <span class="text-danger">*</span>
                </label>
                <input type="file" name="file_csv" id="file_csv" class="form-control" accept=".csv" required>
                <small class="text-muted">
                  El archivo debe contener las columnas:
                  <strong>Proyecto, Cliente, Inicio (YYYY-MM-DD), Fin (YYYY-MM-DD)</strong>
                </small>
              </div>

              <div class="form-group text-right">
                <button type="submit" class="btn btn-primary">
                  <i class="fa fa-upload"></i> Cargar y Previsualizar
                </button>
              </div>
            <?php echo form_close(); ?>

            <hr />
            <p class="text-info">
              Asegúrate de que el archivo esté codificado en <strong>UTF-8</strong> para evitar errores con tildes o caracteres especiales.
            </p>
                <a href="<?= base_url('modules/import_projects/uploads/plantilla_proyectos.csv') ?>" class="btn btn-info mb-3" download>
    Descargar plantilla CSV
</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
</body>
</html>
