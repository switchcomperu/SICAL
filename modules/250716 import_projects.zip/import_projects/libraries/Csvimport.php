<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CSV Import Class
 */
class Csvimport
{
    private $file_data;
    private $delimiter;
    private $detect_line_endings;

    public function __construct($config = [])
    {
        $this->file_data = '';
        $this->delimiter = isset($config['delimiter']) ? $config['delimiter'] : ',';
        $this->detect_line_endings = ini_get('auto_detect_line_endings');

        if (!empty($config)) {
            $this->initialize($config);
        }
    }

    public function initialize($config = [])
    {
        foreach ($config as $key => $val) {
            if (isset($this->$key)) {
                $this->$key = $val;
            }
        }
    }

    public function get_array($filepath = '', $skip_empty_lines = true, $trim_fields = true)
    {
        $csv_array = [];

        if (!file_exists($filepath)) {
            return false;
        }

        if (($handle = fopen($filepath, 'r')) !== false) {
            if ($this->detect_line_endings) {
                ini_set('auto_detect_line_endings', true);
            }

            $row = 0;
            $headers = [];
            while (($data = fgetcsv($handle, 1000, $this->delimiter)) !== false) {
                if ($row == 0) {
                    $headers = $data;
                } else {
                    if ($skip_empty_lines && $data === null) continue;

                    $csv_array[] = array_combine($headers, $trim_fields ? array_map('trim', $data) : $data);
                }
                $row++;
            }

            fclose($handle);

            if ($this->detect_line_endings) {
                ini_set('auto_detect_line_endings', false);
            }

            return $csv_array;
        } else {
            return false;
        }
    }
}
