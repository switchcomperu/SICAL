<?php
defined('BASEPATH') or exit('No direct script access allowed');

register_activation_hook('import_projects', 'import_projects_module_activate');
register_uninstall_hook('import_projects', 'import_projects_module_uninstall');
register_language_files('import_projects', ['import_projects']);
register_hook('admin_init', 'import_projects_module_init_menu_items');

require_once(__DIR__ . '/helpers/import_projects_helper.php');

function import_projects_module_activate() {
    require_once(__DIR__ . '/install.php');
}

function import_projects_module_uninstall() {
    require_once(__DIR__ . '/uninstall.php');
}