<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Script de instalación del módulo Import Projects.
 * Crea las tablas necesarias en la base de datos.
 */

$CI = &get_instance();

// Tabla para historial de importaciones
if (!$CI->db->table_exists(db_prefix() . 'import_projects_history')) {
    $CI->db->query("
        CREATE TABLE `" . db_prefix() . "import_projects_history` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `staff_id` INT NOT NULL,
            `file_name` VARCHAR(255) NOT NULL,
            `total_imported` INT DEFAULT 0,
            `date` DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
}

// Tabla para filas importadas
if (!$CI->db->table_exists(db_prefix() . 'import_projects_rows')) {
    $CI->db->query("
        CREATE TABLE `" . db_prefix() . "import_projects_rows` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `history_id` INT DEFAULT 0,
            `project_name` VARCHAR(255),
            `client` VARCHAR(255),
            `start_date` DATE,
            `end_date` DATE,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
}
