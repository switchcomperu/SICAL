<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Helper para inicializar el menú del módulo Import Projects.
 */
function import_projects_module_init_menu_items()
{
    $CI = &get_instance();

    if (has_permission('import_projects', '', 'view')) {
        $CI->app_menu->add_sidebar_menu_item('import_projects', [
            'slug'     => 'import_projects',
            'name'     => _l('Importar Proyectos'),
            'icon'     => 'fa fa-upload',
            'href'     => admin_url('import_projects'),
            'position' => 36,
            'collapse' => true,
        ]);

        $CI->app_menu->add_sidebar_children_item('import_projects', [
            'slug'     => 'import_projects-importar',
            'name'     => 'Importar',
            'href'     => admin_url('import_projects'),
            'position' => 1,
        ]);

        $CI->app_menu->add_sidebar_children_item('import_projects', [
            'slug'     => 'import_projects-historial',
            'name'     => 'Historial',
            'href'     => admin_url('import_projects/history'),
            'position' => 2,
        ]);

        $CI->app_menu->add_sidebar_children_item('import_projects', [
            'slug'     => 'import_projects-template',
            'name'     => 'Descargar Plantilla',
            'href'     => admin_url('import_projects/template'),
            'position' => 3,
        ]);
    }
}
